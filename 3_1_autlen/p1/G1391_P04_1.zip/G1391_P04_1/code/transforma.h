#ifndef TRANSFORMA_H
#define TRANSFORMA_H

#include <stdio.h>
#include <stdlib.h>
#include "afnd.h"

typedef struct _TransformData TransformData;

AFND * AFNDTransforma(AFND * p_afnd);

#endif